function  [C4] = Hooke(matparam)

% Material parameter
xE   = matparam(1);        % Young's modulus
xnu  = matparam(2);        % Poisson ratio

xblk = xE / (3*(1 - 2*xnu));   % bulk modulus
xmu =  xE / (2*(1 + xnu));     % shear modulus = second Lame parameter

% Dimension of tensors
tdm = 3;
    
% Kronecker delta
I = eye(tdm,tdm);
    
% 4th-order identity tensor
I4 = zeros(tdm,tdm,tdm,tdm);
for i = 1:tdm
    for j = 1:tdm
        for k = 1:tdm
            for l = 1:tdm
                I4(i,j,k,l) = I(i,j)*I(k,l);
            end
        end
    end
end

% 4th-order (sym-) identity tensor
I4sym = zeros(tdm,tdm,tdm,tdm);
for i = 1:tdm
    for j = 1:tdm
        for k = 1:tdm
            for l = 1:tdm
                I4sym(i,j,k,l) = 0.5*( I(i,k)*I(j,l) + I(i,l)*I(j,k) );
            end
        end
    end
end

% 4th-order deviatoric identity tensor
I4dev = zeros(tdm,tdm,tdm,tdm);
for i = 1:tdm
    for j = 1:tdm
        for k = 1:tdm
            for l = 1:tdm
                I4dev(i,j,k,l) = I4sym(i,j,k,l) - 1/3*I4(i,j,k,l);
            end
        end
    end
end



% Elasto-Plastic modulus
C4 = zeros(tdm,tdm,tdm,tdm);
for i = 1:tdm
    for j = 1:tdm
        for k = 1:tdm
            for l = 1:tdm
                C4(i,j,k,l) = xblk*I4(i,j,k,l)+2*xmu*I4dev(i,j,k,l);
            end
        end
    end
end


end
function T2 = T1_dot_T4_dot_T1(G_A, C4, G_B)
%
% T2(j,k) = G_A(i) * C4(i,j,k,l) * G_B(l);
%
[n,dummy,dummy,dummy] = size(C4);
T2 = zeros(n,n);
for i=1:n
    for j=1:n
        for k=1:n
            for l=1:n
                T2(j,k) = T2(j,k) + G_A(i) * C4(i,j,k,l) * G_B(l);
            end;
        end;
    end;
end;




function [ndm, ndf, nnp, nel, nen, x, elem, matparam, drlt, neum, b] = input_quad4()

% global node coordinates
x = [
  0 0;
  1 0;
  1 1;
  0 1;
  0.5 0;
  1 0.5;
  0.5 1;
  0 0.5;
  
];
 
% number of node points and number of spatial dimensions
[nnp, ndm] = size(x);

% number of degrees of freedom per node
ndf = ndm;  % mechanical analysis
 
% connectivity list
connectivity = [1 2 3 4 5 6 7 8]; #; 2 3 6 5; 4 5 8 7; 5 6 9 8]; #5 6 7 8

% number of elements
[nel,nen] = size(connectivity);

% organize connectivity list as a struct
for e = 1:nel
    elem(e).cn = connectivity(e,:);
end;

% Young's modulus
matparam(1) = 210E9;
% Poisson ratio
matparam(2) = 0.3;
% density 
matparam(5) = 2.7e-03;




% boundary conditions
% only homogeneous Dirichlet boundary conditions are allowed!
% Dirichlet boundary condition
%      node    ldof  scale
drlt = [  5               1    0.0; ...
          1               2    0.0; ...
          2               2    0.0;
          5               2    0.0];

% Neumann boundary condition
%      node    ldof  scale
neum = [  3            2    0.25; ...
          4            2    0.25;
          7            2    0.5];
          
          neum(:,3) = 1e9 * neum(:,3);

% body force aka gravity
b = [0; 0];

end


%=========================================================================
% FE Code for 2D quadrilateral elements
%
% Numerische Implementierung der Finite-Elemente-Methode
% Institute of Mechanics, TU Berlin, Germany
%=========================================================================
clear all; close all; clc; 

%=========================================================================
% Pre-processing
%=========================================================================

fprintf("\nLese Aufgabe ein")

[ndm, ndf, nnp, nel, nen, x, elem, matparam, drlt, neum,  b] = input_quad4();

for i = 1:9
  subplot(3,3,i)
  hold on
  for e = 1:nel
      plot([x(elem(e).cn(1:4), 1); x(elem(e).cn(1), 1)], [x(elem(e).cn(1:4), 2); x(elem(e).cn(1), 2)], 'x-', 'color', [0.6, 0.6, 0.6], 'linewidth', 1)
      plot(x(elem(e).cn(5:8), 1), x(elem(e).cn(5:8), 2), 'x', 'color', [0.7, 0.8, 0.7], 'linewidth', 1)
  end;
  plot(x(drlt(:,1), 1), x(drlt(:,1), 2), 'go')   
  plot(x(neum(:,1), 1), x(neum(:,1), 2), 'ro')
  drawnow
endfor

  
% separate dof types
allDofs = (1:1:nnp*ndf)';

% dofs with Dirichlet boundary conditions
numDrltDofs = size(drlt,1);
drltDofs = zeros(numDrltDofs,1);
for i=1:numDrltDofs
    node = drlt(i,1);
    ldof = drlt(i,2);
    drltDofs(i) = (node-1)*ndf + ldof;
end

% free dofs
freeDofs = setdiff(allDofs, drltDofs); 

% dofs with Neumann boundary conditions
numNeumDofs = size(neum,1);
neumDofs = zeros(numNeumDofs,1);
for i=1:numNeumDofs
    node = neum(i,1);
    ldof = neum(i,2);
    neumDofs(i) = (node-1)*ndf + ldof;
end


%=========================================================================
% fe-analysis
%=========================================================================

fprintf("\n\nStarte Berechnung")
%-------------------------------------------------------------------------
% Gauss quadrature, Position and weights
%-------------------------------------------------------------------------

% number of quadrature points
nqp = 9; 

if (nqp == 4)
  % quadrature points
  qpt = zeros(nqp,ndm);
  qpt(1,:) = [-sqrt(3.0)/3.0   -sqrt(3.0)/3.0];
  qpt(2,:) = [ sqrt(3.0)/3.0   -sqrt(3.0)/3.0];
  qpt(3,:) = [-sqrt(3.0)/3.0    sqrt(3.0)/3.0];
  qpt(4,:) = [ sqrt(3.0)/3.0    sqrt(3.0)/3.0];

  % weights
  w8 = zeros(nqp,1);
  w8(1) = 1;
  w8(2) = 1;
  w8(3) = 1;
  w8(4) = 1;

  %-------------------------------------------------------------------------
  % 4 noded quadrilateral element, bilinear shape functions
  %-------------------------------------------------------------------------
  masterelement = repmat(struct('N', zeros(nen,1), 'gamma', zeros(nen,ndm)), nqp,1);


    for q = 1:nqp
        
        xi  = qpt(q,:);
        
        masterelement(q).N(1) = 0.25*(1.0-xi(1))*(1.0-xi(2));
        masterelement(q).N(2) = 0.25*(1.0+xi(1))*(1.0-xi(2));
        masterelement(q).N(3) = 0.25*(1.0+xi(1))*(1.0+xi(2));
        masterelement(q).N(4) = 0.25*(1.0-xi(1))*(1.0+xi(2));
        
        masterelement(q).gamma(1,:) = [-0.25*(1.0-xi(2))   -0.25*(1.0-xi(1))];
        masterelement(q).gamma(2,:) = [ 0.25*(1.0-xi(2))   -0.25*(1.0+xi(1))];
        masterelement(q).gamma(3,:) = [ 0.25*(1.0+xi(2))    0.25*(1.0+xi(1))];
        masterelement(q).gamma(4,:) = [-0.25*(1.0+xi(2))    0.25*(1.0-xi(1))];
        
    end

  
  
elseif nqp == 9
  
    % quadrature points
    qpt = zeros(nqp,ndm);
    qpt(1,:) = [-sqrt(0.6),  -sqrt(0.6)];
    qpt(2,:) = [-sqrt(0.6),           0];
    qpt(3,:) = [-sqrt(0.6),   sqrt(0.6)];
    qpt(4,:) = [0,           -sqrt(0.6)];
    qpt(5,:) = [0,                    0];
    qpt(6,:) = [0,            sqrt(0.6)];
    qpt(7,:) = [sqrt(0.6),   -sqrt(0.6)];
    qpt(8,:) = [sqrt(0.6),            0];
    qpt(9,:) = [sqrt(0.6),    sqrt(0.6)];
    
    

    % weights
    w8 = 1/81 * [25; 40; 25; 40; 64; 40; 25; 40; 25];
    
    masterelement = repmat(struct('N', zeros(nen,1), 'gamma', zeros(nen,ndm)), nqp,1);
      
  
  
      for q = 1:nqp
      
        xi  = qpt(q,:);
        
        masterelement(q).N(1) = -0.25 * (1-xi(1))*(1-xi(2))*(1+xi(1)+xi(2));
        masterelement(q).N(2) = -0.25 * (1+xi(1))*(1-xi(2))*(1-xi(1)+xi(2));
        
        masterelement(q).N(3) = -0.25 * (1+xi(1))*(1+xi(2))*(1-xi(1)-xi(2));
        masterelement(q).N(4) = -0.25 * (1-xi(1))*(1+xi(2))*(1+xi(1)-xi(2));
        
        masterelement(q).N(5) = 0.5 * (1-xi(1)^2)*(1-xi(2));
        masterelement(q).N(6) = 0.5 * (1+xi(1))*(1-xi(2)^2);
        
        masterelement(q).N(7) = 0.5 * (1-xi(1)^2)*(1+xi(2));
        masterelement(q).N(8) = 0.5 * (1-xi(1))*(1-xi(2)^2);
        
        
        
        masterelement(q).gamma(1,:) = [-0.25*(-1+xi(2))*(2*xi(1)+xi(2)),    -0.25*(-1+xi(1))*(xi(1)+2*xi(2))];
        masterelement(q).gamma(5,:) = [xi(1)*(-1+xi(2))                ,            0.5*(1+xi(1))*(-1+xi(1))];
        masterelement(q).gamma(2,:) = [0.25*(-1+xi(2))*(xi(2)-2*xi(1)) ,      0.25*(1+xi(1))*(2*xi(2)-xi(1))];
        masterelement(q).gamma(6,:) = [-0.5*(1+xi(2))*(-1+xi(2))       ,                    -xi(2)*(1+xi(1))];
        masterelement(q).gamma(3,:) = [0.25*(1+xi(2))*(2*xi(1)+xi(2))  ,      0.25*(1+xi(1))*(xi(1)+2*xi(2))];
        masterelement(q).gamma(7,:) = [-xi(1)*(1+xi(2))                ,           -0.5*(1+xi(1))*(-1+xi(1))];
        masterelement(q).gamma(4,:) = [-0.25*(1+xi(2))*(xi(2)-2*xi(1)),     -0.25*(-1+xi(1))*(2*xi(2)-xi(1))];
        masterelement(q).gamma(8,:) = [0.5*(1+xi(2))*(-1+xi(2)),                            xi(2)*(-1+xi(1))];
      
      end
      
end



%-------------------------------------------------------------------------
% Analysis
%-------------------------------------------------------------------------

% Material law
% Für jeden Gausspunkt/ jedes Element in der Schleife separat berechnen,
% wenn verschiedene Materialien möglich sein sollen.
% Ansonsten reicht einmal.
E4 = Hooke(matparam);

% unknown node displacements
u = zeros(ndf*nnp,1);



    % Neumann loads for this timestep
    fsur = zeros(ndf*nnp,1);
    numNeumDofs = size(neum,1);
    neumValue = neum(:,3);
    fsur(neumDofs) = neumValue;
    
    % Dirichlet boundary conditions
    drltValue = drlt(:,3);
    

        % initialise global volume force vector
        fvol = zeros(ndf*nnp,1);
        
        % initialise global tangent stiffness matrix
        K = zeros(ndf*nnp,ndf*nnp);
        
        % initialise global residuum
        fext = zeros(ndf*nnp,1);
        
        % element loop
        for e=1:nel
            
            % dofs belonging to element e
            edof = zeros(ndf, nen);
            for ien=1:nen
                for idf=1:ndf
                    edof(idf,ien) = ndf*elem(e).cn(ien)+idf-ndf;
                end
            end
            
            gdof = reshape(edof, ndf*nen, 1);
            
            % coordinates of the element nodes
            xe = zeros(ndm, nen);
            for idm = 1:ndm
                xe(idm,:) = x(elem(e).cn,idm);
            end
            
            
            % density
            rho = matparam(5);
            
            % element internal force vector
            finte = zeros(nen*ndf,1);
            
            % element volume force vector
            fvole = zeros(nen*ndf,1);
            
            % element tangent stiffness matrix
            Ke = zeros(nen*ndf,nen*ndf);
            
            % integration loop = summation over all quadrature points q
            for q = 1:nqp
                
                % shape functions
                N = masterelement(q).N;
                
                % gradients of the shape functions for quadrature point q
                gamma = masterelement(q).gamma;
                
                % Jacobian matrix at quadrature point q
                Je = xe*gamma;
                detJe = det(Je);
                
                
                if detJe <= 0
                    fprintf('Error: detJ <=  in element e= %d\n',e);
                    error('STOP');
                end
                
                % reference volume belonging to quadrature point q
                dv = detJe * w8(q);
                
                % save volume of quadrature point
                elem(e).dv(q) = dv;
                
                % inverse Jacobian
                invJe = inv(Je);
                
                % Gradient of the shape functions wrt. to x
                G = gamma*invJe;
                
                
                for A = 1:nen
                    
                    % Gradient of shape func belonging to node A
                    G_A = G(A,:);
                    
                    % volume force contribution of quadrature point q to
                    % node A of element e
                    fvolA = N(A) * rho * b * dv;
                    fvole((A-1)*ndf+1:A*ndf) = fvole((A-1)*ndf+1:A*ndf) + fvolA;
                    
                    for B = 1:nen
                        
                        % Gradient of shape func belonging to node B
                        G_B = G(B,:);
                        
                        % stiffness contribution of quadrature point q to
                        % nodes A and B of element e
                        KAB = T1_dot_T4_dot_T1(G_A, E4(1:ndm,1:ndm,1:ndm,1:ndm), G_B) *dv;
                        
                        % insert KAB into the element stiffness matrix
                        Ke((A-1)*ndf+1:A*ndf, (B-1)*ndf+1:B*ndf) =  Ke((A-1)*ndf+1:A*ndf, (B-1)*ndf+1:B*ndf) + KAB;
                        
                    end
                    
                end
                
            end % integration loop

            
            % assemble fvole into global volume force vector fvol
            fvol(gdof) = fvol(gdof) + fvole;
            
            % assemble Ke into the global stiffness matrix K
            K(gdof,gdof) = K(gdof,gdof) + Ke;
            
        end % element loop
        
        % calculate residuum and its 2-norm
        fext(freeDofs) = fvol(freeDofs) + fsur(freeDofs);

        
            % modified right hand side
                fext(freeDofs) = fext(freeDofs) - K(freeDofs,drltDofs)...
                    * (drltValue-u(drltDofs));
                u(drltDofs)=drltValue;
            % calculate increment of node displacements
            du = zeros(size(u));
            du(freeDofs) = K(freeDofs,freeDofs) \ fext(freeDofs);
            u(freeDofs) = u(freeDofs) + du(freeDofs);
            u(drltDofs) = drltValue;
        

    
    drawnow
%=========================================================================
% Post-processing
%=========================================================================
fprintf("\n\nPostprocessing")
        % Material parameter
        xE   = matparam(1);        % Young's modulus
        xnu  = matparam(2);        % Poisson ratio

        xblk = xE / (3*(1 - 2*xnu));   % bulk modulus
        xmu =  xE / (2*(1 + xnu));     % shear modulus = second Lame parameter

        tdm = 3;
        I = eye(tdm,tdm);
        
        % element loop
        plotdata = zeros(nel*nqp, 9);
        nq = 1;
        
        for e=1:nel
            
            % dofs belonging to element e
            edof = zeros(ndf, nen);
            for ien=1:nen
                for idf=1:ndf
                    edof(idf,ien) = ndf*elem(e).cn(ien)+idf-ndf;
                end
            end
            
            gdof = reshape(edof, ndf*nen, 1);
            
            % coordinates of the element nodes
            xe = zeros(ndm, nen);
            for idm = 1:ndm
                xe(idm,:) = x(elem(e).cn,idm);
            end
            
            % displacement values at the element nodes
            ue = u(edof);
            
            
            % integration loop = summation over all quadrature points q
            for q = 1:nqp
                
                % shape functions
                N = masterelement(q).N;
                
                % gradients of the shape functions for quadrature point q
                gamma = masterelement(q).gamma;
               
                % Jacobian matrix at quadrature point q
                Je = xe*gamma;
                detJe = det(Je);
                
                if detJe <= 0
                    fprintf(fid,'Error: detJ <=  in element e= %d\n',e);
                    error('STOP');
                end
                
                % reference volume belonging to quadrature point q
                dv = detJe * w8(q);
                
                % save volume of quadrature point
                elem(e).dv(q) = dv;
                
                % inverse Jacobian
                invJe = inv(Je);
                
                % Gradient of the shape functions wrt. to x
                G = gamma*invJe;
                
                % Gradient of u
                h = zeros(tdm,tdm); % Initialize 3x3
                h(1:ndm,1:ndm) = ue*G; % Evaluate  ue*G is only 2x2 -> fill in 3x3
                
                % Linear strains
                eps = 1/2*(h+h');
                
                plotdata(nq, 1:2) = xe*N;
                
                % Deviatoric stress
                vol_sigma = xblk*trace(eps)*I;
                dev_eps = eps-1/3*trace(eps)*I;
                dev_sigma = 2*xmu*(dev_eps);
                sigma = vol_sigma + dev_sigma
                plotdata(nq, 3) = sigma(1,1);
                plotdata(nq, 4) = sigma(2,2);
                plotdata(nq, 5) = sigma(3,3);
                plotdata(nq, 6) = sigma(1,2);
                plotdata(nq, 7) = sigma(1,3);
                plotdata(nq, 8) = sigma(2,3);
                
                sigma_v = sqrt(sigma(1,1)^2 + sigma(2,2)^2 + sigma(3,3)^2 - sigma(1,1)*sigma(2,2) - sigma(1,1)*sigma(3,3) - sigma(2,2)*sigma(3,3) + 3*(sigma(1,2)^2 + sigma(1, 3)^2 + sigma(2,3)^2));
                plotdata(nq, 9) = sigma_v;
                
                nq = nq + 1;
            end
         end
         
         colormap ("jet") ;
         sigma_v_max = max(plotdata(:,3));
    
         for i = 3:9
          subplot(3,3,i)
          scatter(plotdata(:,1), plotdata(:,2), [], (plotdata(:,i)), 'filled')   
         endfor
         
         drawnow

         fprintf("\n\n")